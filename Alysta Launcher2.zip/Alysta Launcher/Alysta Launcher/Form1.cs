﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Alysta_Launcher
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Visible = true;  
            prgBLauncher.Visible = true;
            lblYuzde.Visible = true;
            pictureBox1.Visible = true;
            lblBaslangic1.Visible = true;
            Random r = new Random();
            int random = r.Next(0, 30);
            for (int i = 0; i <= 100; i += random)
            {
                if (i <= 10)
                {
                    Thread.Sleep(random * 100);
                    lblBaslangic1.Text = "Ayarlar Yükleniyor...";
                    prgBLauncher.Value = i;
                    lblYuzde.Text = prgBLauncher.Value.ToString();
                    
                }
                else if (i >= 30 && i < 40)
                {
                    Thread.Sleep(random * 100);
                    lblBaslangic1.Text = "Bağlantı kuruluyor...";
                    prgBLauncher.Value = i;
                    lblYuzde.Text = prgBLauncher.Value.ToString();
                    
                }
                else if (i >= 40 && i < 50)
                {
                    Thread.Sleep(random * 100);
                    lblBaslangic1.Text = "Sunucu Denetleniyor...";
                    prgBLauncher.Value = i;
                    lblYuzde.Text = prgBLauncher.Value.ToString();
                    
                }
                else if (i >= 60 && i < 70)
                {
                    Thread.Sleep(random * 100);
                    lblBaslangic1.Text = "Sistem Ayarlanıyor...";
                    prgBLauncher.Value = i;
                    lblYuzde.Text = prgBLauncher.Value.ToString();
                    
                    
                }
                else if(i >= 70 && i < 100)
                {
                    Thread.Sleep(random * 100);
                    lblBaslangic1.Text = "Launcher Başlatılıyor...";
                    prgBLauncher.Value = i;
                    lblYuzde.Text = prgBLauncher.Value.ToString();
                    
                }
                
                random = r.Next(0, 30);
            }
            prgBLauncher.Value = 100;
            lblYuzde.Text = prgBLauncher.Value.ToString();

            this.Hide();
            prgBLauncher.Visible = false;
            lblYuzde.Visible = false;
            pictureBox1.Visible = false;
            lblBaslangic1.Visible = false;
            
            AlystaGirisEkrani Giris2Frm = new AlystaGirisEkrani();
            Giris2Frm.Show();
        }

      
    }
}