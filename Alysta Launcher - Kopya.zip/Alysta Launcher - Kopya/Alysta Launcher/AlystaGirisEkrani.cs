﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Alysta_Launcher
{
    public partial class AlystaGirisEkrani : Form
    {
        public AlystaGirisEkrani()
        {
            InitializeComponent();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            pcrBosCheck.Visible = false;
            pcrXCheck.Visible = true;
        }

        private void pcrXCheck_Click(object sender, EventArgs e)
        {
            pcrBosCheck.Visible = true;
            pcrXCheck.Visible = false;
        }
    }
}
